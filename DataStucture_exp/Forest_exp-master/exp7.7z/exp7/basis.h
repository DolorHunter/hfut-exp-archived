#pragma once
#include<iostream>

using namespace std;

void _pause(){
    cout << "\nPress Enter to continue." << endl;
    getchar();
    getchar();
}
